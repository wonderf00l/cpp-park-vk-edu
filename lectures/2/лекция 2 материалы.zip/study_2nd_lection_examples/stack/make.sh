g++ -g -O0 main.cpp -o main.o
