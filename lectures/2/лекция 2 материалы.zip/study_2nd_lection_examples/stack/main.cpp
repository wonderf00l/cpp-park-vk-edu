#include <iostream>

void recursive(int i)
{
   if (i == 0)  { return; }
   if (i == -262000) {
       std::cout<<"Near to crash"<<std::endl;
   }
   recursive(i-1);
}

int main(void)
{
    recursive(10000);
    recursive(-1);
    return 0;
}
