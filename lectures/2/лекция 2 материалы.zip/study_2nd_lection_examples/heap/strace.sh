strace -f -e trace=brk,write ./main.o 2>&1 1>/dev/null  | less
