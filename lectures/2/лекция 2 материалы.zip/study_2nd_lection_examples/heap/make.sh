g++ main.cpp -o main.o
