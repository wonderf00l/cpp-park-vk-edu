#include <iostream>

int main(int argc, char* argv[]) {
  int i = 0;
  while (i < 1000) {
    std::cout << i << std::endl;
    new int[100];
    ++i;
  }

  return 0;
}
