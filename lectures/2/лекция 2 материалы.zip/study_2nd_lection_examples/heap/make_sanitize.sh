g++ -fsanitize=address -g main.cpp -o main-s.o
