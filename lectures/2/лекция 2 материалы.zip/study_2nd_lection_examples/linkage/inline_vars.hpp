inline int not_inline1 = 1;
inline int not_inline2 = 2;
