static int func1(int a, int b);   // internal
//int func1(int a, int b);        // external (by default)  won't compile (double definition)
int call_func1(int a, int b);     // external (by default)

void modify_non_const();

static int non_const_var = 5;     // internal
				  
//namespace
//{
//  int non_const_var = 5;     // internal
//}

extern int i;
//int i;
