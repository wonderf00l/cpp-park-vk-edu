#include "constants.hpp"

const int my_const1 = 10;  // the definition
const int my_const2 = 20;  // the definition
