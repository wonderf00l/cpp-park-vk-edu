#include "functions.hpp"
#include "inline_vars.hpp"

int i = 10;

int func1(int a, int b)
{
  return a - b;
}

int call_func1(int a, int b)
{
  return func1(a, b);
}

void modify_non_const()
{
  non_const_var = 2;  
}
