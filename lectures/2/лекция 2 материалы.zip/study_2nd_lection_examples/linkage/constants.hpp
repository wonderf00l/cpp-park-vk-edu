extern const int my_const1;   // declaration only
extern const int my_const2;   // declaration only
