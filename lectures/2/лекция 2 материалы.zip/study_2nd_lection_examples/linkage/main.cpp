#include <iostream>
#include "functions.hpp"
#include "constants.hpp"
#include "inline_vars.hpp"

//int i = 6;  //double definition

int func1(int a, int b)
{
  return a + b;
}

int main(int argc, char* argv[])
{
  std::cout << "call 'own' func1: " << func1(5, 3) << std::endl;
  std::cout << "call 'neighbour' func1: " << call_func1(5, 3) << std::endl;

  std::cout << "before modify:" << non_const_var << std::endl;
  modify_non_const();
  std::cout << "after modify:" << non_const_var <<  std::endl;

  std::cout << "extern const1:" << my_const1 << std::endl;
  std::cout << "extern const2:" << my_const2 << std::endl;

  std::cout << "not_inline1:" << not_inline1 << std::endl;
  std::cout << "not_inline2:" << not_inline2 << std::endl;
  return 0;
}
