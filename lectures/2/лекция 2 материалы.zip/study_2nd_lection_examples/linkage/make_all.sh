g++ main.cpp another_def.cpp constants.cpp -o main.o
