cat yes_example.txt |./test_cpp
