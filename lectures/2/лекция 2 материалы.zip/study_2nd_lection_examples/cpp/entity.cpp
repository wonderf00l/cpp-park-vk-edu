#include "entity.hpp"
#include "io.hpp"

const std::string from_prefix = "From:";
const std::string to_prefix = "To:";
const std::string subject_prefix = "Subject:";
const std::string suspicious_word = "швейцарские часы";

bool read_entity(std::istream& file, Entity& entity)
{
  if (!read_expected_field(file, entity.from, from_prefix) ||
      !read_expected_field(file, entity.to, to_prefix) ||
      !read_expected_field(file, entity.subject, subject_prefix))
  {
    return false;
  }
  entity.content = read_till_eof(file);
  return true;
}

bool check_entity(const Entity& entity)
{
  return entity.from.find(suspicious_word) != std::string::npos ||
         entity.subject.find(suspicious_word) != std::string::npos ||
         entity.content.find(suspicious_word) != std::string::npos;
}
