#include <iostream>
#include <string>

struct Entity
{
  std::string from;
  std::string to;
  std::string subject;
  std::string content;
};

bool read_entity(std::istream& from, Entity& entity);
bool check_entity(const Entity& entity);