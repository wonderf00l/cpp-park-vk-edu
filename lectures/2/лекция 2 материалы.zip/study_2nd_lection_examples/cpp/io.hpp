#include <iostream>
#include <string>

bool read_expected_field(std::istream& from,
                         std::string& dst,
                         const std::string& expected_prefix);
std::string read_till_eof(std::istream& from);