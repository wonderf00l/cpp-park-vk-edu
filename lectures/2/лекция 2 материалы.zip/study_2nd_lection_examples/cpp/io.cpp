#include "io.hpp"

bool read_expected_field(std::istream& from,
                         std::string& dst,
                         const std::string& expected_prefix)
{
  std::string line;
  if (!std::getline(from, line))
  {
    return false;
  }

  const size_t prefix_size = expected_prefix.size();

  if (line.substr(0, prefix_size) == expected_prefix)
  {
    dst = line.substr(prefix_size, line.size()-prefix_size);
    return true;
  }

  return false;
}

std::string read_till_eof(std::istream& from)
{ 
  std::string res;
  std::string line;
  while (std::getline(from, line))
  {
    res += line;
  }
  return res;
}