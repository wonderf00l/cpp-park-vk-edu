#include "entity.hpp"

int main()
{
  Entity entity;
  if (!read_entity(std::cin, entity))
  {
    std::cerr << "ERROR: Failed to read entity" << std::endl;
    return 1;
  }

  std::cout << (check_entity(entity) ? "YES" : "NO") << std::endl;
  return 0;
}