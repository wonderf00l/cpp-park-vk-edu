#include <iostream>

int& bar()
{
    int n = 10;
    return n;
}

int main() {
    int* ptr = new int(5);
    std::cout<<"*ptr=" << *ptr <<std::endl;
    delete ptr;
    std::cout<<"*ptr=" << *ptr <<std::endl;
    
    int i = bar();
    std::cout<< i <<std::endl;
    return 0;
}
