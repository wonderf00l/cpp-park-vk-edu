#include "io.h"
#include <stdlib.h>
#include <string.h>

#define INIT_LINE_BUF_SIZE 1024ul
#define BUF_GROWTH_FACTOR 2

int extend_buf(char** buf, size_t* capacity)
{
  *capacity *= BUF_GROWTH_FACTOR;
  char* newBuf = (char*) realloc( *buf, *capacity);
  if (newBuf == NULL)
  {
    return 0;
  }
  *buf = newBuf;
  return 1;
}

int skip_expected_prefix(FILE* file, char* buf, const char* expected)
{
  size_t expected_len = strlen(expected);
  return fgets(buf, expected_len + 1, file) && !strncmp(buf, expected, expected_len);
}

char* read_line(FILE* file, char* buf, size_t capacity)
{
  size_t offset = 0;
  while (fgets(buf + offset, capacity - offset, file) != NULL)
  {
    offset += strlen(buf + offset);
    if (buf[offset - 1] == '\n')
    {
      break;
    }
    if (offset == capacity - 1 && !extend_buf( &buf, &capacity))
    {
      free(buf);
      buf = NULL;
      return NULL;
    }
  }
  return buf;
}

void remove_trailing_linefeed(char* s)
{
  size_t len = strlen(s);
  if (len > 0 && s[len - 1] == '\n')
  {
    s[len - 1] = '\0';
  }
}

char* read_expected_field(FILE* file, const char* expected_prefix)
{
  size_t capacity = INIT_LINE_BUF_SIZE;
  char* buf = (char*) malloc(capacity);
  if (!skip_expected_prefix(file, buf, expected_prefix))
  {
    free(buf);
    buf = NULL;
    return NULL;
  }
  char* s = read_line(file, buf, capacity);
  if (s != NULL) {
    remove_trailing_linefeed(s);
  }
  return s;
}

char* read_till_eof(FILE* file)
{
  size_t offset = 0;
  size_t capacity = INIT_LINE_BUF_SIZE;
  char* buf = (char*) malloc(capacity);
  while (fgets(buf + offset, capacity - offset - 1, file) != NULL)
  {
    offset += strlen(buf + offset);
    if (offset == capacity - 1 && !extend_buf( &buf, &capacity))
    {
      free(buf);
      buf = NULL;
      return NULL;
    }
  }
  return buf;
}