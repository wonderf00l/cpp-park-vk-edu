#include "entity.h"

int main()
{
  struct Entity* entity = read_entity(stdin);

  if (entity == NULL)
  {
    fputs("ERROR: Failed to read entity\n", stderr);
    return 1;
  }

  puts(check_entity(entity) ? "YES" : "NO");
  free_entity(entity);

  entity = NULL;
  return 0;
}