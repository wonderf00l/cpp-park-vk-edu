cat no_example.txt |./test_c
