#include <stdio.h>

char* read_expected_field(FILE* file, const char* expected_prefix);
char* read_till_eof(FILE* file);