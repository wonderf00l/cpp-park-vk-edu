#include "entity.h"
#include "io.h"
#include <stdlib.h>
#include <string.h>

#define FROM_PREFIX "From: "
#define TO_PREFIX "To: "
#define SUBJECT_PREFIX "Subject: "
#define SUSPICIOUS_SUBSTR "швейцарские часы"

struct Entity* read_entity(FILE* file)
{
  struct Entity* entity = (struct Entity*) calloc(1, sizeof(struct Entity));
  entity->from = read_expected_field(file, FROM_PREFIX);
  if (entity->from == NULL)
  {
    goto err;
  }
  entity->to = read_expected_field(file, TO_PREFIX);
  if (entity->to == NULL)
  {
    goto err;
  }
  entity->subject = read_expected_field(file, SUBJECT_PREFIX);
  if (entity->subject == NULL)
  {
    goto err;
  }
  entity->content = read_till_eof(file);
  return entity;
  err:
    free_entity(entity);
  entity = NULL;
  return NULL;
}

void free_entity(struct Entity* entity)
{
  free(entity->from);
  entity->from = NULL;
  free(entity->to);
  entity->to = NULL;
  free(entity->subject);
  entity->subject = NULL;
  free(entity->content);
  entity->content = NULL;
  free(entity);
  entity = NULL;
}

int check_entity(const struct Entity* entity)
{
 return strstr(entity->from, SUSPICIOUS_SUBSTR) ||
        strstr(entity->subject, SUSPICIOUS_SUBSTR) ||
        (entity->content && strstr(entity->content, SUSPICIOUS_SUBSTR));
}