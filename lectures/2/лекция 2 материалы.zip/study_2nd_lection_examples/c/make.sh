gcc -o test_c main.c io.c entity.c
