#include <stdio.h>

struct Entity
{
  char* from;
  char* to;
  char* subject;
  char* content;
};

struct Entity* read_entity(FILE* file);
void free_entity(struct Entity* entity);
int check_entity(const struct Entity* entity);